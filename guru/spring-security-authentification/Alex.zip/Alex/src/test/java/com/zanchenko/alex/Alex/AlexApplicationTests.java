package com.zanchenko.alex.Alex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlexApplicationTests {

	@Test
	void contextLoads() {
	}

}
