package com.zanchenko.alex.Alex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlexApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlexApplication.class, args);
	}

}
